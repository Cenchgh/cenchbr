function toggleMenu() {
  alert('Menu clicado! Aqui você pode implementar um menu lateral.');
}

function adicionarAoCarrinho() {
  alert('Produto adicionado ao carrinho!');
}
